@extends('layouts.staff')

@section('content')
    <div class="container py-4">
        <h1>Quản lý Banner</h1>
        <p>Đây là trang quản lý banner, chỉ dành cho nhân viên có quyền "Quản lý Banner".</p>
        <!-- Thêm nội dung quản lý banner tại đây -->
    </div>
@endsection