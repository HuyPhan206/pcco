@extends('layouts.staff')

@section('content')
    <div class="container py-4">
        <h1>Quản lý Người dùng</h1>
        <p>Đây là trang quản lý người dùng, chỉ dành cho nhân viên có quyền "Quản lý Người dùng".</p>
        <!-- Thêm nội dung quản lý người dùng tại đây -->
    </div>
@endsection