@extends('layouts.staff')

@section('content')
    <div class="container py-4">
        <h1>Quản lý Sản phẩm</h1>
        <p>Đây là trang quản lý sản phẩm, chỉ dành cho nhân viên có quyền "Quản lý Sản phẩm".</p>
        <!-- Thêm nội dung quản lý sản phẩm tại đây -->
    </div>
@endsection