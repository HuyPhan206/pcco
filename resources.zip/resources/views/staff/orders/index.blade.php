@extends('layouts.staff')

@section('content')
    <div class="container py-4">
        <h1>Quản lý Đơn hàng</h1>
        <p>Đây là trang quản lý đơn hàng, chỉ dành cho nhân viên có quyền "Quản lý Đơn hàng".</p>
        <!-- Thêm nội dung quản lý đơn hàng tại đây -->
    </div>
@endsection