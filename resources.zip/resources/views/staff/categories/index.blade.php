@extends('layouts.staff')

@section('content')
    <div class="container py-4">
        <h1>Quản lý Danh mục</h1>
        <p>Đây là trang quản lý danh mục, chỉ dành cho nhân viên có quyền "Quản lý Danh mục".</p>
        <!-- Thêm nội dung quản lý danh mục tại đây -->
    </div>
@endsection